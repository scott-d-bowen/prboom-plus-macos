#define PACKAGE_NAME "PrBoom-Plus"
#define PACKAGE_TARNAME "prboom-plus"
#define PACKAGE_VERSION "2.6.2"
#define PACKAGE_HOMEPAGE "https://github.com/coelckers/prboom-plus"
#define PACKAGE_STRING "PrBoom-Plus 2.6.2"

#define DOOMWADDIR "/usr/local/share/games/doom"
#define PRBOOMDATADIR "/usr/local/share/prboom-plus"

/* #undef WORDS_BIGENDIAN */

#define HAVE_GETOPT
#define HAVE_MMAP
/* #undef HAVE_CREATE_FILE_MAPPING */
/* #undef HAVE_SCHED_SETAFFINITY */
#define HAVE_USLEEP
#define HAVE_STRSIGNAL
#define HAVE_MKSTEMP

#define HAVE_SYS_WAIT_H
#define HAVE_UNISTD_H
/* #undef HAVE_ASM_BYTEORDER_H */
#define HAVE_DIRENT_H

#define HAVE_SDL_JOYSTICKGETAXIS
#define HAVE_LIBSDL2_IMAGE
#define HAVE_LIBSDL2_MIXER
#define HAVE_NET
#define USE_SDL_NET

/* #undef HAVE_LIBPCREPOSIX */
#define HAVE_LIBZ
/* #undef HAVE_LIBMAD */
/* #undef HAVE_LIBFLUIDSYNTH */
/* #undef HAVE_LIBDUMB */
#define HAVE_LIBVORBISFILE
/* #undef HAVE_LIBPORTMIDI */
/* #undef HAVE_ALSA */

#define SIMPLECHECKS
#define ZONEIDCHECK

/* #undef RANGECHECK */
/* #undef INSTRUMENTED */
/* #undef TIMEDIAG */
/* #undef HEAPCHECK */
/* #undef HEAPDUMP */
